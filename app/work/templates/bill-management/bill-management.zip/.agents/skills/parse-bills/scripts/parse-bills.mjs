#!/usr/bin/env node
import { readFile, mkdir, stat, appendFile, writeFile } from "node:fs/promises";
import { existsSync, realpathSync } from "node:fs";
import { basename, extname, join } from "node:path";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

export const OUTPUT_COLUMNS = [
  "交易单号",
  "交易对方",
  "交易时间",
  "交易渠道",
  "交易类型",
  "创建时间",
  "商品",
  "备注",
  "当前状态",
  "支付方式",
  "收入/支出",
  "金额(元)",
];

export const CATEGORY_OPTIONS = [
  "餐饮",
  "发红包",
  "服饰",
  "服务",
  "工资",
  "购物",
  "奖金",
  "交通",
  "教育",
  "酒店",
  "旅行",
  "其他",
  "生活缴费",
  "退款",
  "医疗",
  "娱乐",
  "转账",
  "房租",
  "公积金",
];

const CHANNELS = {
  wx: { prefix: "wx", label: "微信支付" },
  zfb: { prefix: "zfb", label: "支付宝" },
  zs: { prefix: "zs", label: "其他" },
};

const HEADER_ALIASES = {
  transactionId: ["交易单号", "交易号", "微信支付订单号", "交易订单号", "商户单号"],
  counterparty: ["交易对方", "对方", "商户名称", "收/付款方"],
  transactionTime: ["交易时间", "付款时间", "支付时间", "发生时间", "入账时间"],
  createdTime: ["创建时间", "交易创建时间", "订单创建时间"],
  sourceType: ["交易类型", "交易分类", "类型", "账单分类"],
  item: ["商品", "商品名称", "商品说明", "交易商品", "交易说明", "说明"],
  remark: ["备注", "交易备注"],
  status: ["当前状态", "交易状态", "状态"],
  paymentMethod: ["支付方式", "付款方式", "收/付款方式", "资金状态"],
  direction: ["收入/支出", "收/支", "收支", "资金流向"],
  amount: ["金额(元)", "金额（元）", "交易金额", "金额", "收入金额", "支出金额"],
};

export async function parsePaymentBill(filePath, options = {}) {
  const ext = extname(filePath).toLowerCase();
  const name = basename(filePath);

  if (ext === ".xlsx" || ext === ".xls" || name.includes("微信")) {
    return parseWeChatBill(filePath, options);
  }

  if (ext === ".csv" || name.includes("支付宝")) {
    return parseCsvBill(filePath, options);
  }

  throw new Error("不支持的文件格式，仅支持 CSV、微信 XLS/XLSX 或支付宝 CSV 账单");
}

export async function parseWeChatBill(filePath, options = {}) {
  const xlsx = await importXlsx();
  const buffer = await readFile(filePath);
  const workbook = xlsx.read(buffer);
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const rawData = xlsx.utils.sheet_to_json(worksheet, { header: 1, raw: false });
  const headerRowIndex = findHeaderRow(rawData);

  if (headerRowIndex === -1) {
    throw new Error('未能在 Excel 中找到有效账单表头（需包含"交易时间"和"金额"相关列）');
  }

  const records = xlsx.utils.sheet_to_json(worksheet, {
    range: headerRowIndex,
    raw: false,
    defval: "",
  });
  return transformRows(records, filePath, options);
}

export async function parseCsvBill(filePath, options = {}) {
  const buffer = await readFile(filePath);
  const content = decodeChineseCsv(buffer);
  const rows = parseCsv(content);
  const headerRowIndex = findHeaderRow(rows);

  if (headerRowIndex === -1) {
    throw new Error("未找到有效账单表头");
  }

  const headers = rows[headerRowIndex].map(cleanText);
  const records = rows.slice(headerRowIndex + 1).map((row) => {
    return Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ""]));
  });
  return transformRows(records, filePath, options);
}

export async function writeMonthlyCsv(records, dataDir, options = {}) {
  const pendingByFile = new Map();
  const seenByFile = new Map();
  const stats = {
    parsedRows: records.length,
    newRows: 0,
    duplicates: 0,
    ignoredRows: 0,
    fallbackIds: records.filter((row) => row["交易单号"].includes("-fallback-")).length,
    files: {},
  };

  for (const record of records) {
    const date = parseDateTime(record["交易时间"]);
    if (!date || !record["金额(元)"]) {
      stats.ignoredRows += 1;
      continue;
    }

    const month = `${date.year}-${String(date.month).padStart(2, "0")}`;
    const outputPath = join(dataDir, `${month}.csv`);
    if (!seenByFile.has(outputPath)) {
      seenByFile.set(outputPath, await readExistingIds(outputPath));
    }

    const seen = seenByFile.get(outputPath);
    if (seen.has(record["交易单号"])) {
      stats.duplicates += 1;
      continue;
    }

    seen.add(record["交易单号"]);
    if (!pendingByFile.has(outputPath)) pendingByFile.set(outputPath, []);
    pendingByFile.get(outputPath).push(record);
  }

  for (const [outputPath, rows] of pendingByFile) {
    stats.files[outputPath] = rows.length;
    stats.newRows += rows.length;
    if (!options.dryRun) {
      await appendCsvRows(outputPath, rows);
    }
  }

  return stats;
}

function transformRows(rows, filePath, options = {}) {
  const channel = detectChannel(filePath, rows, options.channel);
  return rows.map((row) => transformRow(row, channel, options.categories, options.allowMissingCategory)).filter(Boolean);
}

function transformRow(row, channel, categories = {}, allowMissingCategory = false) {
  const rawTransactionTime = pick(row, "transactionTime") || pick(row, "createdTime");
  const rawCreatedTime = pick(row, "createdTime") || rawTransactionTime;
  const transactionTime = parseDateTime(rawTransactionTime);
  const createdTime = parseDateTime(rawCreatedTime) || transactionTime;
  const amount = normalizeAmount(pick(row, "amount"));

  if (!transactionTime || !amount) return null;

  const direction = normalizeDirection(pick(row, "direction"), pick(row, "amount"));
  const item = pick(row, "item");
  const counterparty = pick(row, "counterparty");
  const remark = pick(row, "remark");
  const sourceType = pick(row, "sourceType");
  const rawId = pick(row, "transactionId");
  const id = rawId ? `${channel.prefix}-${rawId}` : fallbackId(channel.prefix, row);
  const category = getCategory({ id, categories, sourceType, allowMissingCategory });

  return {
    "交易单号": id,
    "交易对方": counterparty,
    "交易时间": formatDateTime(transactionTime),
    "交易渠道": channel.label,
    "交易类型": category,
    "创建时间": formatDateTime(createdTime),
    "商品": item,
    "备注": remark,
    "当前状态": pick(row, "status"),
    "支付方式": pick(row, "paymentMethod"),
    "收入/支出": direction,
    "金额(元)": amount,
    "_原始来源类型": sourceType,
  };
}

function detectChannel(filePath, rows, forcedChannel) {
  if (forcedChannel) return CHANNELS[forcedChannel];
  const haystack = [basename(filePath), ...Object.keys(rows[0] ?? {})].join(" ").toLowerCase();
  if (haystack.includes("微信") || haystack.includes("wechat") || haystack.includes("wx")) {
    return CHANNELS.wx;
  }
  if (haystack.includes("支付宝") || haystack.includes("alipay") || haystack.includes("zfb")) {
    return CHANNELS.zfb;
  }
  if (haystack.includes("招商") || haystack.includes("cmb") || haystack.includes("zs")) {
    return CHANNELS.zs;
  }
  return { prefix: "other", label: "其他" };
}

function findHeaderRow(rows) {
  let bestIndex = -1;
  let bestScore = 0;
  rows.forEach((row, index) => {
    if (!Array.isArray(row)) return;
    const normalized = new Set(row.map(normalizeHeader));
    const score = Object.values(HEADER_ALIASES).filter((aliases) => {
      return aliases.some((alias) => normalized.has(normalizeHeader(alias)));
    }).length;
    if (score > bestScore) {
      bestScore = score;
      bestIndex = index;
    }
  });
  return bestScore >= 3 ? bestIndex : -1;
}

function pick(row, field) {
  const aliases = new Set(HEADER_ALIASES[field].map(normalizeHeader));
  for (const [key, value] of Object.entries(row)) {
    if (aliases.has(normalizeHeader(key))) return cleanText(value);
  }
  return "";
}

function getCategory({ id, categories, sourceType, allowMissingCategory }) {
  const category = categories[id];
  if (!category && allowMissingCategory) return "";
  if (!category) {
    throw new Error(`缺少交易 ${id} 的 AI 分类结果，请先使用 --emit-classification-input 导出待分类记录，再通过 --categories-file 传入分类 JSON`);
  }
  if (!CATEGORY_OPTIONS.includes(category)) {
    throw new Error(`交易 ${id} 的分类 "${category}" 不在允许范围内；原始来源类型为 "${sourceType || "无"}"`);
  }
  return category;
}

function normalizeDirection(value, amountRaw = "") {
  const text = cleanText(value);
  if (text.includes("不计") || text.includes("无需")) return "不计入收支";
  if (text.includes("收入") || text === "收") return "收入";
  if (text.includes("支出") || text === "支") return "支出";
  const amountText = cleanText(amountRaw);
  if (amountText.startsWith("-")) return "支出";
  if (amountText.startsWith("+")) return "收入";
  return text === "不计收支" ? "不计入收支" : "支出";
}

function normalizeAmount(value) {
  const cleaned = cleanText(value).replace(/[￥¥元,\s+]/g, "").replace(/[^\d.-]/g, "");
  if (!cleaned) return "";
  const amount = Math.abs(Number.parseFloat(cleaned));
  return Number.isFinite(amount) ? amount.toFixed(2) : "";
}

function parseDateTime(value) {
  const text = cleanText(value).replace(/-/g, "/").replace(/\s+/g, " ");
  if (!text) return null;
  const match = text.match(/^(\d{4})[\/年](\d{1,2})[\/月](\d{1,2})日?(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (!match) return null;
  const [, year, month, day, hour = "0", minute = "0", second = "0"] = match;
  return {
    year: Number(year),
    month: Number(month),
    day: Number(day),
    hour: Number(hour),
    minute: Number(minute),
    second: Number(second),
  };
}

function formatDateTime(date) {
  return `${date.year}/${date.month}/${date.day} ${pad(date.hour)}:${pad(date.minute)}:${pad(date.second)}`;
}

function fallbackId(prefix, row) {
  const parts = ["counterparty", "transactionTime", "amount", "direction", "item", "paymentMethod"].map((field) =>
    pick(row, field)
  );
  const digest = createHash("sha1").update(parts.join("|")).digest("hex").slice(0, 16);
  return `${prefix}-fallback-${digest}`;
}

async function readExistingIds(outputPath) {
  if (!existsSync(outputPath)) return new Set();
  const rows = parseCsv(decodeChineseCsv(await readFile(outputPath)));
  const headers = rows[0] ?? [];
  const idIndex = headers.findIndex((header) => cleanText(header) === "交易单号");
  if (idIndex === -1) return new Set();
  return new Set(rows.slice(1).map((row) => cleanText(row[idIndex])).filter(Boolean));
}

async function appendCsvRows(outputPath, rows) {
  await mkdir(join(outputPath, ".."), { recursive: true });
  const exists = existsSync(outputPath) && (await stat(outputPath)).size > 0;
  const headerRow = Object.fromEntries(OUTPUT_COLUMNS.map((column) => [column, column]));
  const csv = toCsvRows(exists ? rows : [headerRow, ...rows]);
  await appendFile(outputPath, `${exists ? "" : "\ufeff"}${csv}`, "utf8");
}

function toCsvRows(rows) {
  return `${rows.map((row) => OUTPUT_COLUMNS.map((column) => escapeCsv(row[column])).join(",")).join("\n")}\n`;
}

function parseCsv(content) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let i = 0; i < content.length; i += 1) {
    const char = content[i];
    const next = content[i + 1];

    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
      continue;
    }

    if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      if (row.some((value) => cleanText(value))) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }

  row.push(cell.replace(/\r$/, ""));
  if (row.some((value) => cleanText(value))) rows.push(row);
  return rows;
}

function decodeChineseCsv(buffer) {
  const utf8 = new TextDecoder("utf-8").decode(buffer);
  if (utf8.includes("交易时间") || utf8.includes("交易单号")) return utf8;
  try {
    return new TextDecoder("gb18030").decode(buffer);
  } catch {
    return utf8;
  }
}

async function importXlsx() {
  const requireFromCwd = createRequire(`${process.cwd()}/`);
  try {
    return requireFromCwd("xlsx");
  } catch {}

  try {
    return await import("xlsx");
  } catch {
    throw new Error("解析微信 Excel 账单需要安装 xlsx 依赖；CSV 账单无需额外依赖");
  }
}

function cleanText(value) {
  return value == null ? "" : String(value).replace(/^\ufeff/, "").trim().replace(/^"|"$/g, "").trim();
}

function normalizeHeader(value) {
  return cleanText(value).replace(/\s+/g, "");
}

function escapeCsv(value) {
  const text = value == null ? "" : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function pad(number) {
  return String(number).padStart(2, "0");
}

function parseArgs(argv) {
  const args = { inputs: [], dataDir: "./data", dryRun: false, channel: "", categoriesFile: "", classificationInput: "" };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--data-dir") {
      args.dataDir = argv[++i];
    } else if (arg === "--channel") {
      args.channel = argv[++i];
    } else if (arg === "--dry-run") {
      args.dryRun = true;
    } else if (arg === "--categories-file") {
      args.categoriesFile = argv[++i];
    } else if (arg === "--emit-classification-input") {
      args.classificationInput = argv[++i];
    } else {
      args.inputs.push(arg);
    }
  }
  if (!args.inputs.length) {
    throw new Error("请提供至少一个账单文件路径");
  }
  if (args.channel && !CHANNELS[args.channel]) {
    throw new Error("--channel 只能是 wx、zfb 或 zs");
  }
  return args;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const allRecords = [];
  let inputFiles = 0;
  const categories = args.categoriesFile ? await readCategoriesFile(args.categoriesFile) : {};

  for (const input of args.inputs) {
    const records = await parsePaymentBill(input, {
      channel: args.channel || undefined,
      categories,
      allowMissingCategory: Boolean(args.classificationInput),
    });
    inputFiles += 1;
    allRecords.push(...records);
  }

  if (args.classificationInput) {
    await writeClassificationInput(args.classificationInput, allRecords);
    console.log(JSON.stringify({ inputFiles, classificationInput: args.classificationInput, rows: allRecords.length }, null, 2));
    return;
  }

  const stats = await writeMonthlyCsv(allRecords, args.dataDir, { dryRun: args.dryRun });
  console.log(JSON.stringify({ inputFiles, ...stats }, null, 2));
}

async function readCategoriesFile(filePath) {
  const parsed = JSON.parse(await readFile(filePath, "utf8"));
  const entries = parsed.transactionTypes ?? parsed.categories ?? parsed;
  return Object.fromEntries(Object.entries(entries).map(([id, category]) => [cleanText(id), cleanText(category)]));
}

async function writeClassificationInput(filePath, records) {
  const rows = records.map((record) => ({
    "交易单号": record["交易单号"],
    "交易对方": record["交易对方"],
    "交易时间": record["交易时间"],
    "交易渠道": record["交易渠道"],
    "商品": record["商品"],
    "备注": record["备注"],
    "原始来源类型": record["_原始来源类型"],
    "当前状态": record["当前状态"],
    "支付方式": record["支付方式"],
    "收入/支出": record["收入/支出"],
    "金额(元)": record["金额(元)"],
    "允许分类": CATEGORY_OPTIONS,
    "分类提示": buildClassificationPromptContext(record),
  }));
  await writeFile(filePath, `${JSON.stringify(rows, null, 2)}\n`, "utf8");
}

function buildClassificationPromptContext(record) {
  const hints = ["由当前大模型根据本条账单语义逐条判断，不能使用脚本关键词表或静态映射。"];
  if (record["商品"].includes("饭卡充值")) {
    hints.push("商品包含饭卡充值，通常应判断为餐饮。");
  }
  return hints.join(" ");
}

if (realpathSync(fileURLToPath(import.meta.url)) === realpathSync(process.argv[1])) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
