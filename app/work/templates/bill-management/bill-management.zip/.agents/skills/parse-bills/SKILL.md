---
name: parse-bills
description: 将导出的微信支付、支付宝或类似个人账单 CSV 文件解析为 ./data 下按月归档的标准化 CSV 文件。当 Codex 需要转换原始中文支付账单、按交易月份追加到 2026-01.csv 这类文件、分类交易、保留必需账单结构、拆分跨月输入，并按带渠道前缀的交易单号去重时使用。
---

# 解析账单

## 工作流程

当需要将原始导出账单转换为本项目的标准化 CSV 格式时，使用此技能。

1. 定位输入账单文件；除非用户给出明确路径，通常位于 `./原始账单`。
2. 检查少量样本，识别来源渠道：微信（`wx`）、支付宝（`zfb`）、招商银行（`zs`）或其他。
3. 优先使用 `scripts/parse-bills.mjs`，以获得确定性的字段解析、按月拆分和去重行为。
4. 不允许用脚本内置关键词或静态映射直接生成 `交易类型`。必须先让脚本导出待分类记录，再由当前大模型根据每条账单的 `交易对方`、`商品`、`备注`、`收入/支出`、`金额(元)`、`支付方式`、原始来源类型等信息逐条判断 `交易类型`。
5. 将大模型生成的分类结果作为分类文件传回脚本，再将输出 CSV 写入 `./data`，并按交易日期所在月份命名（`YYYY-MM.csv`）。
6. 解析完成后，报告统计数量：已解析行数、跳过的重复行数、忽略行数，以及发生变更的输出文件。

## 必需输出结构

始终按以下精确顺序写入这些列：

`交易单号`, `交易对方`, `交易时间`, `交易渠道`, `交易类型`, `创建时间`, `商品`, `备注`, `当前状态`, `支付方式`, `收入/支出`, `金额(元)`

使用带 BOM 的 UTF-8（`utf-8-sig`）输出 CSV，便于 Excel 打开。当输入提供完整时间戳时，保持 `交易时间` 和 `创建时间` 的格式为 `YYYY/M/D HH:MM:SS`。

## 脚本

从项目根目录运行解析器：

```bash
node ./.agents/skills/parse-bills/scripts/parse-bills.mjs ./原始账单/账单.csv --emit-classification-input /tmp/bill-categories-input.json
```

随后由当前大模型逐条判断分类，并生成分类 JSON：

```json
{
  "wx-100001": "餐饮",
  "zfb-200001": "交通"
}
```

最后写入标准化月度 CSV：

```bash
node ./.agents/skills/parse-bills/scripts/parse-bills.mjs ./原始账单/账单.csv --data-dir ./data --categories-file /tmp/bill-categories.json
```

处理多个文件时：

```bash
node ./.agents/skills/parse-bills/scripts/parse-bills.mjs ./原始账单/2026-01.csv ./原始账单/2026-02.csv --emit-classification-input /tmp/bill-categories-input.json
node ./.agents/skills/parse-bills/scripts/parse-bills.mjs ./原始账单/2026-01.csv ./原始账单/2026-02.csv --data-dir ./data --categories-file /tmp/bill-categories.json
```

当用户要求预览变更时，最终写入步骤先使用 `--dry-run`。仅在自动识别错误，或源文件缺少可识别表头时，才使用 `--channel wx|zfb|zs`。

该脚本是 ESM JavaScript，参考 `/Users/liujinglun/Desktop/payment-bill-import/scripts/bill-parser.mjs` 编写。它使用原生 CSV 解析处理 CSV 账单。对于微信 Excel 文件（`.xls`/`.xlsx`），需确保当前 Node 环境可以导入 `xlsx`。

## 大模型分类规则

添加或调整字段映射、分类边界时，阅读 `references/schema.md`。

核心分类：

`餐饮`, `发红包`, `服饰`, `服务`, `工资`, `购物`, `奖金`, `交通`, `教育`, `酒店`, `旅行`, `其他`, `生活缴费`, `退款`, `医疗`, `娱乐`, `转账`, `房租`, `公积金`

分类必须由当前大模型逐条判断，判断依据至少包括：`交易对方`、`商品`、`备注`、`收入/支出`、`金额(元)`、`支付方式`、原始账单中的 `交易类型/交易分类/账单分类`。原始来源类型只能作为参考，不能无条件照搬；当来源类型和商品/交易对方明显冲突时，以账单语义为准。

提示词上下文：当 `商品` 包含 `饭卡充值` 时，通常应将 `交易类型` 判断为 `餐饮`。该规则只作为大模型分类提示，不允许在脚本中硬编码。

## 去重

将 `交易单号` 构造为 `<channel-prefix>-<source transaction id>`，其中前缀包括 `wx`、`zfb` 和 `zs`。写入前，与目标月份文件中已有的 `交易单号` 进行比较。跳过重复记录，并且不要重写无关行。

如果输入中没有稳定的交易单号，则根据渠道、交易对方、交易时间、金额、收支方向、商品和支付方式派生备用单号；由于备用去重依据的权威性较弱，需要在最终回复中说明这一点。
