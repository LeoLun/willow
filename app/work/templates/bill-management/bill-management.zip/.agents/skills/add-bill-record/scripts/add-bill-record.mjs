#!/usr/bin/env node
import { appendFile, mkdir, readFile, stat } from "node:fs/promises";
import { existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { join } from "node:path";

const OUTPUT_COLUMNS = [
  "交易单号",
  "交易对方",
  "交易时间",
  "交易渠道",
  "交易类型",
  "创建时间",
  "商品",
  "备注",
  "当前状态",
  "支付方式",
  "收入/支出",
  "金额(元)",
];

const CATEGORY_OPTIONS = new Set([
  "餐饮",
  "发红包",
  "服饰",
  "服务",
  "工资",
  "购物",
  "奖金",
  "交通",
  "教育",
  "酒店",
  "旅行",
  "其他",
  "生活缴费",
  "退款",
  "医疗",
  "娱乐",
  "转账",
  "房租",
  "公积金",
]);

const DIRECTIONS = new Set(["收入", "支出", "不计入收支"]);

export async function addBillRecord(record, options = {}) {
  const dataDir = options.dataDir ?? "./data";
  const row = normalizeRecord(record);
  const date = parseDateTime(row["交易时间"]);
  const outputPath = join(dataDir, `${date.year}-${String(date.month).padStart(2, "0")}.csv`);
  const existingIds = await readExistingIds(outputPath);
  const duplicate = existingIds.has(row["交易单号"]);

  if (!duplicate && !options.dryRun) {
    await appendCsvRows(outputPath, [row]);
  }

  return {
    outputFile: outputPath,
    transactionId: row["交易单号"],
    duplicate,
    added: !duplicate && !options.dryRun,
    dryRun: Boolean(options.dryRun),
    row,
  };
}

function normalizeRecord(record) {
  if (!record || typeof record !== "object" || Array.isArray(record)) {
    throw new Error("--record 必须是 JSON 对象");
  }

  const transactionTime = formatDateTime(requireDate(record.transactionTime ?? record["交易时间"]));
  const createdTime = formatDateTime(parseDateTime(record.createdTime ?? record["创建时间"] ?? transactionTime));
  const counterparty = cleanText(record.counterparty ?? record["交易对方"]);
  const item = cleanText(record.item ?? record.product ?? record["商品"] ?? record.description ?? "");
  const remark = cleanText(record.remark ?? record["备注"] ?? "");
  const category = normalizeCategory(record.category ?? record["交易类型"] ?? inferCategory(`${counterparty} ${item} ${remark}`));
  const direction = normalizeDirection(record.direction ?? record["收入/支出"] ?? inferDirection(`${counterparty} ${item} ${remark}`));
  const amount = normalizeAmount(record.amount ?? record["金额(元)"]);
  const paymentMethod = cleanText(record.paymentMethod ?? record["支付方式"] ?? "手动记录") || "手动记录";
  const status = cleanText(record.status ?? record["当前状态"] ?? "手动记录") || "手动记录";
  const channel = cleanText(record.channel ?? record["交易渠道"] ?? "其他") || "其他";

  if (!counterparty) throw new Error("缺少交易对方");
  if (!amount) throw new Error("缺少有效金额");

  const id = cleanText(record.id ?? record.transactionId ?? record["交易单号"]) || manualId({
    transactionTime,
    counterparty,
    category,
    item,
    remark,
    paymentMethod,
    direction,
    amount,
  });

  return {
    "交易单号": id.startsWith("manual-") ? id : `manual-${id}`,
    "交易对方": counterparty,
    "交易时间": transactionTime,
    "交易渠道": channel,
    "交易类型": category,
    "创建时间": createdTime,
    "商品": item || category,
    "备注": remark,
    "当前状态": status,
    "支付方式": paymentMethod,
    "收入/支出": direction,
    "金额(元)": amount,
  };
}

function manualId(parts) {
  const digest = createHash("sha1")
    .update(
      [
        parts.transactionTime,
        parts.counterparty,
        parts.category,
        parts.item,
        parts.remark,
        parts.paymentMethod,
        parts.direction,
        parts.amount,
      ].join("|")
    )
    .digest("hex")
    .slice(0, 16);
  return `manual-${digest}`;
}

function normalizeCategory(value) {
  const category = cleanText(value);
  if (!CATEGORY_OPTIONS.has(category)) {
    throw new Error(`交易类型必须是允许值之一，收到: ${category || "(空)"}`);
  }
  return category;
}

function normalizeDirection(value) {
  const direction = cleanText(value);
  if (!DIRECTIONS.has(direction)) {
    throw new Error(`收入/支出必须是 收入、支出 或 不计入收支，收到: ${direction || "(空)"}`);
  }
  return direction;
}

function inferDirection(text) {
  if (/收到|收款|收入|工资|奖金|退款到账/.test(text)) return "收入";
  if (/不计|报销/.test(text)) return "不计入收支";
  return "支出";
}

function inferCategory(text) {
  const rules = [
    ["房租", /房租|租金|房东/],
    ["工资", /工资|薪资|薪水/],
    ["奖金", /奖金|绩效/],
    ["公积金", /公积金/],
    ["餐饮", /饭卡充值|吃饭|餐|咖啡|奶茶|外卖|食堂/],
    ["发红包", /红包/],
    ["生活缴费", /水费|电费|燃气|话费|物业|宽带/],
    ["医疗", /医院|药房|医疗|诊所/],
    ["交通", /打车|公交|地铁|火车|机票|高铁/],
    ["酒店", /酒店|宾馆|民宿/],
    ["旅行", /旅行|旅游|景区|门票/],
    ["退款", /退款/],
    ["转账", /转账/],
    ["服饰", /衣服|鞋|服饰/],
    ["娱乐", /电影|游戏|娱乐|会员/],
    ["教育", /课程|培训|考试|书/],
  ];
  return rules.find(([, pattern]) => pattern.test(text))?.[0] ?? "其他";
}

function normalizeAmount(value) {
  const cleaned = cleanText(value).replace(/[￥¥元,\s+]/g, "").replace(/[^\d.-]/g, "");
  if (!cleaned) return "";
  const amount = Math.abs(Number.parseFloat(cleaned));
  return Number.isFinite(amount) ? amount.toFixed(2) : "";
}

function requireDate(value) {
  const date = parseDateTime(value);
  if (!date) throw new Error("缺少有效交易时间");
  return date;
}

function parseDateTime(value) {
  if (typeof value === "object" && value?.year && value?.month && value?.day) return value;
  const text = cleanText(value).replace(/-/g, "/").replace(/\s+/g, " ");
  const match = text.match(/^(\d{2,4})[\/年](\d{1,2})[\/月](\d{1,2})日?(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (!match) return null;
  let [, year, month, day, hour = "0", minute = "0", second = "0"] = match;
  if (year.length === 2) year = `20${year}`;
  return {
    year: Number(year),
    month: Number(month),
    day: Number(day),
    hour: Number(hour),
    minute: Number(minute),
    second: Number(second),
  };
}

function formatDateTime(date) {
  return `${date.year}/${date.month}/${date.day} ${pad(date.hour)}:${pad(date.minute)}:${pad(date.second)}`;
}

async function readExistingIds(outputPath) {
  if (!existsSync(outputPath)) return new Set();
  const rows = parseCsv(await readFile(outputPath, "utf8"));
  const headers = rows[0] ?? [];
  const idIndex = headers.findIndex((header) => cleanText(header) === "交易单号");
  if (idIndex === -1) return new Set();
  return new Set(rows.slice(1).map((row) => cleanText(row[idIndex])).filter(Boolean));
}

async function appendCsvRows(outputPath, rows) {
  await mkdir(join(outputPath, ".."), { recursive: true });
  const exists = existsSync(outputPath) && (await stat(outputPath)).size > 0;
  const headerRow = Object.fromEntries(OUTPUT_COLUMNS.map((column) => [column, column]));
  const csv = toCsvRows(exists ? rows : [headerRow, ...rows]);
  await appendFile(outputPath, `${exists ? "" : "\ufeff"}${csv}`, "utf8");
}

function toCsvRows(rows) {
  return `${rows.map((row) => OUTPUT_COLUMNS.map((column) => escapeCsv(row[column])).join(",")).join("\n")}\n`;
}

function parseCsv(content) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < content.length; index += 1) {
    const char = content[index];
    const next = content[index + 1];
    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      if (row.some((value) => cleanText(value))) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }

  row.push(cell.replace(/\r$/, ""));
  if (row.some((value) => cleanText(value))) rows.push(row);
  return rows;
}

function escapeCsv(value) {
  const text = value == null ? "" : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function cleanText(value) {
  return value == null ? "" : String(value).replace(/^\ufeff/, "").trim();
}

function pad(number) {
  return String(number).padStart(2, "0");
}

function parseArgs(argv) {
  const args = { record: "", dataDir: "./data", dryRun: false };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--record") {
      args.record = argv[++index];
    } else if (arg === "--data-dir") {
      args.dataDir = argv[++index];
    } else if (arg === "--dry-run") {
      args.dryRun = true;
    } else {
      throw new Error(`未知参数: ${arg}`);
    }
  }
  if (!args.record) throw new Error("缺少 --record JSON");
  return args;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const record = JSON.parse(args.record);
  const result = await addBillRecord(record, { dataDir: args.dataDir, dryRun: args.dryRun });
  console.log(JSON.stringify(result, null, 2));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
