---
name: add-bill-record
description: 将一条或多条手动描述的账单记录添加到本项目 ./data 下的标准化月度 CSV 文件中。当 Codex 需要把房租、工资、转账、退款、餐饮、水电缴费或购物等中文自然语言收支说明转换为单条标准化记录，推断日期、分类、收支方向、金额和交易对方，按交易日期路由到 YYYY-MM.csv，生成手动交易单号，并防止手动记录重复时使用。
---

# 添加账单记录

## 工作流程

当用户用自然语言描述一笔交易，并要求添加到账单 CSV 数据中时，使用此技能。

1. 将用户的说明解析为结构化记录。如果年份、月份、日期、金额或收支方向不明确，写入前先提出一个简洁问题。
2. 使用当前项目时区和上下文规范化日期。对于 `26 年 4 月 15 号` 这类简写，如果用户未提供具体时间，则使用 `2026/4/15 00:00:00`。
3. 根据 `references/manual-record-rules.md` 推断字段。
4. 使用一个 JSON 对象运行 `scripts/add-bill-record.mjs`。当用户要求预览时，先使用 `--dry-run`。
5. 报告目标 CSV 文件、记录是已添加还是因重复被跳过，以及生成的 `交易单号`。

## 必需 JSON 输入

向 `--record` 传入一个 JSON 对象：

```json
{
  "transactionTime": "2026/4/15 00:00:00",
  "counterparty": "房东",
  "category": "房租",
  "item": "4月房租",
  "remark": "",
  "status": "手动记录",
  "paymentMethod": "手动记录",
  "direction": "支出",
  "amount": 2300
}
```

最小输入可以省略 `category`、`item`、`remark`、`status`、`paymentMethod`、`direction` 和 `createdTime`；脚本会填充安全默认值。优先将 `item` 填为用户的自然语言描述，例如 `4月房租`。

## 脚本

从项目根目录运行：

```bash
node /Users/liujinglun/.codex/skills/add-bill-record/scripts/add-bill-record.mjs --record '{"transactionTime":"2026/4/15 00:00:00","counterparty":"房东","category":"房租","item":"4月房租","direction":"支出","amount":2300}' --data-dir ./data
```

使用 `--dry-run` 可在不写入的情况下预览。

## 输出结构

脚本会写入与 `parse-bills` 相同的 CSV 列：

`交易单号`, `交易对方`, `交易时间`, `交易渠道`, `交易类型`, `创建时间`, `商品`, `备注`, `当前状态`, `支付方式`, `收入/支出`, `金额(元)`

手动记录使用：

- `交易渠道`: `其他`
- `交易单号`: `manual-<sha1 digest>`，根据规范化日期、交易对方、分类、商品、收支方向、金额、支付方式和备注生成
- CSV 编码：新文件使用带 BOM 的 UTF-8

## 重复规则

写入前，将生成的 `交易单号` 与目标月份文件中已有的单号进行比较。如果已存在，则跳过写入并报告为重复记录。这会让同一条自然语言说明的重复执行保持幂等。
