# Manual Bill Record Rules

## Columns

Write columns in this exact order:

`交易单号`, `交易对方`, `交易时间`, `交易渠道`, `交易类型`, `创建时间`, `商品`, `备注`, `当前状态`, `支付方式`, `收入/支出`, `金额(元)`

## Defaults

- `交易渠道`: `其他`
- `创建时间`: same as `交易时间` unless explicitly provided
- `当前状态`: `手动记录`
- `支付方式`: `手动记录` unless the user says WeChat, Alipay, bank card, cash, etc.
- `收入/支出`: infer from wording; default to `支出` for paid/spent/bought/缴纳, `收入` for received/salary/bonus/refund income.
- `金额(元)`: keep two decimal places.

## Date Rules

- Route the output file by transaction date month: `./data/YYYY-MM.csv`.
- Interpret `26 年` as `2026 年`.
- If a date has no time, use `00:00:00`.
- If the user gives only a month/day and the current year is available from context, use the current year.
- Ask before writing if the year cannot be inferred safely.

## Category Inference

Allowed categories:

`餐饮`, `发红包`, `服饰`, `服务`, `工资`, `购物`, `奖金`, `交通`, `教育`, `酒店`, `旅行`, `其他`, `生活缴费`, `退款`, `医疗`, `娱乐`, `转账`, `房租`, `公积金`

Hints:

- 房租、租金、支付房东: `房租`
- 工资、薪资: `工资`
- 奖金、绩效: `奖金`
- 公积金: `公积金`
- 饭卡充值、吃饭、咖啡、外卖、餐厅: `餐饮`
- 红包: `发红包`
- 水电燃气、话费、物业、宽带: `生活缴费`
- 医院、药房、医疗: `医疗`
- 打车、公交、地铁、火车、机票: `交通`
- 酒店、宾馆: `酒店`
- 旅行、景区、门票: `旅行`
- 退款: `退款`
- 转账: `转账`
- 衣服、鞋、服饰: `服饰`
- 电影、游戏、娱乐、会员: `娱乐`
- 课程、培训、考试、书: `教育`
- Unknown or ambiguous: `其他`

## Example

User: `26 年4 月 15 号支付房东 4 月房租 2300 元`

Record:

```json
{
  "transactionTime": "2026/4/15 00:00:00",
  "counterparty": "房东",
  "category": "房租",
  "item": "4月房租",
  "remark": "26 年4 月 15 号支付房东 4 月房租 2300 元",
  "status": "手动记录",
  "paymentMethod": "手动记录",
  "direction": "支出",
  "amount": 2300
}
```
